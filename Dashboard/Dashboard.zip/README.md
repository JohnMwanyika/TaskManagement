# TaskManagement

This is a web application used to create, manage and assign tasks

Technologies Used
<ul>
  <li>NodeJs</li>
  <li>Javascript</li>
  <li>Pug Templating Engine</li>
  <li>Bootstrap</li>
</ul>
